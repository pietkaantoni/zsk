﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Sprawdzian_AP_gr2
{
    internal class Program
    {
        public interface IAnimal
        {
            void MakeSound();
            void Eat();
        }
        public abstract class Animal : IAnimal
        {
            public string Name { get; set; }
            public string Species { get; set; }
            public int Age { get; set; }
            public string Owner { get; set; }

            public Animal(string name, string species, int age, string owner)
            {
                Name = name;
                Species = species;
                Age = age;
                Owner = owner;
            }
            public void Eat()
            {
                Console.WriteLine($"{Name} je");
            }
            public abstract void MakeSound();
        }
        public class Dog : Animal
        {
            public Dog(string name, string species, int age, string owner) : base(name, species, age, owner)
            {
            }

            public override void MakeSound()
            {
                Console.WriteLine("Hau!");
            }
        }
        public class Cat : Animal
        {
            public Cat(string name, string species, int age, string owner) : base(name, species, age, owner)
            {
            }
            public override void MakeSound()
            {
                Console.WriteLine("Miau!");
            }
        }
        
        static void Main(string[] args)
        {
            Dog dog = new Dog("Azor", "Pies", 2, "Jan Kowalski");
            Cat cat = new Cat("Filemon", "Kot", 3, "Anna Nowak");

            dog.MakeSound();
            dog.Eat();
            cat.MakeSound();
            cat.Eat();

            List<Animal> animals = new List<Animal>();
            animals.Add(dog);
            animals.Add(cat);
            animals.Add(new Dog("Reksio", "Pies", 4, "Piotr Wiśniewski"));
            animals.Add(new Cat("Mruczek", "Kot", 1, "Katarzyna Zielińska"));

            foreach (Animal animal in animals)
            {
                animal.MakeSound();
                animal.Eat();
            }


            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("1. Sortowanie według właściciela");
                Console.WriteLine("2. Sortowanie według gatunku");
                Console.WriteLine("3. Sortowanie według wieku");
                Console.WriteLine("4. Sortowanie według imienia");
                Console.WriteLine("5. Wyjście");
                int option = GetCorrectIntInput("Wybierz opcję: ");

                switch (option)
                {
                    case 1:
                        SortAnimalsByOwner(animals);
                        break;
                    case 2:
                        SortAnimalsBySpecies(animals);
                        break;
                    case 3:
                        SortAnimalsByAge(animals);
                        break;
                    case 4:
                        SortAnimalsByName(animals);
                        break;
                    case 5:
                        exit = true;
                        return;
                    default:
                        Console.WriteLine("Wybrano opcję z poza zakresu działania.");
                        break;
                }

                Console.WriteLine("Naciśnij przycisk, aby kontynuować.");
                Console.ReadKey();
                Console.Clear();
            }
            Console.ReadKey();
        }
        
        public static void ShowAnimals(List<Animal> animals)
        {
            for (int i = 0; i < animals.Count(); i++)
            {
                Console.WriteLine($"{i}. {animals[i].Species} {animals[i].Name} ma {animals[i].Age} lat i jego właścicielem jest {animals[i].Owner}");
            }
        }

        private static void SortAnimalsByName(List<Animal> animals)
        {
            animals.Sort( (a, b) => a.Name.CompareTo(b.Name));
            ShowAnimals(animals);
        }

        private static void SortAnimalsByAge(List<Animal> animals)
        {
            animals.Sort((a, b) => a.Age.CompareTo(b.Age));
            ShowAnimals(animals);
        }

        private static void SortAnimalsBySpecies(List<Animal> animals)
        {
            animals.Sort((a, b) => a.Species.CompareTo(b.Species));
            ShowAnimals(animals);
        }

        private static void SortAnimalsByOwner(List<Animal> animals)
        {
            animals.Sort((a, b) => a.Owner.CompareTo(b.Owner));
            ShowAnimals(animals);
        }

        public static int GetCorrectIntInput(string prompt)
        {
            int number;
            Console.WriteLine(prompt);
            bool isValid = int.TryParse(Console.ReadLine(), out number);
            while (!isValid)
            {
                Console.WriteLine("Podanoi nieprawidłowe dane.\n{0}", prompt);
                isValid = int.TryParse(Console.ReadLine(), out number);
            }
            return number;
        }
        
    }
}
